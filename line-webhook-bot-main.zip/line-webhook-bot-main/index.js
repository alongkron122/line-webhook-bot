require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

const ACCESS_TOKEN = process.env.LINE_ACCESS_TOKEN;

app.post('/webhook', async (req, res) => {
    const events = req.body.events;
    if (!events || events.length === 0) return res.sendStatus(200);

    for (const event of events) {
        if (event.type === 'message' && event.message.type === 'text') {
            const replyToken = event.replyToken;
            const userMessage = event.message.text;
            await replyToUser(replyToken, `คุณพิมพ์ว่า: ${userMessage}`);
        }
    }
    res.sendStatus(200);
});

async function replyToUser(replyToken, text) {
    const url = "https://api.line.me/v2/bot/message/reply";
    const headers = {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${ACCESS_TOKEN}`
    };
    const body = JSON.stringify({
        replyToken: replyToken,
        messages: [{ type: "text", text: text }]
    });

    await fetch(url, { method: "POST", headers, body });
}

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
